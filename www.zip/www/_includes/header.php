    <header id="cabecalho">

        <nav id="menu-top">
            <title><h1>Menu principal</h1></title>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="prep_receitas.php">Preparar receitas</a></li>
                <li><a href="sobre.php">Sobre</a></li>
            </ul>
        </nav>
        <hr/>



    </header>
