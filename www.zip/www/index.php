<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8"/>
    <title>FarmaSIM</title>
    <link rel="stylesheet" href="_css/estilo.css"/>
</head>
<body>
<div id="interface">
<?php include("_includes/header.php"); ?>

<p>
    home em constrção
</p>




<?php include ("_includes/footer.php"); ?>

</div>

</body>

</html>